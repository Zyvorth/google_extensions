'use strict';

/**
 * Duck Annotator content script.
 *
 * One file, one linear flow: anchor -> wrap -> persist -> reload -> re-anchor.
 * All floating UI (tooltip, note editor, mascot) renders inside a single
 * Shadow DOM root for style isolation. Highlight spans/note icons must be
 * real inline elements in the host page, so they're styled defensively via
 * content.css instead.
 *
 * Storage model (chrome.storage.local only):
 *   duckAnnotatorSettings          -> { mascotEnabled: boolean }
 *   duckAnnotator_<origin+path>    -> Annotation[]
 *
 * Annotation: { id, startXPath, startOffset, endXPath, endOffset, text, note, createdAt }
 */

(() => {
  const PAGE_KEY = 'duckAnnotator_' + location.origin + location.pathname;

  let annotations = [];      // in-memory, mirrors what's actually rendered on the page
  let unresolvedAnnotations = [];
  let tooltipEl = null;
  let noteEditorEl = null;
  let activeNoteId = null;
  let shadowHost = null;
  let shadowRoot = null;

  // ---------------------------------------------------------------------
  // Shadow DOM root for floating UI (tooltip / note editor / mascot)
  // ---------------------------------------------------------------------

  const SHADOW_STYLES = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: -apple-system, "Segoe UI", Helvetica, Arial, sans-serif; }

    .da-tooltip {
      position: absolute;
      background: #050505;
      border: 2px solid #000000;
      padding: 4px;
      z-index: 2147483647;
      pointer-events: auto;
      display: flex;
      gap: 4px;
    }
    .da-tooltip button {
      display: flex;
      align-items: center;
      gap: 6px;
      background: #ffffff;
      color: #000000;
      border: none;
      padding: 6px 10px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
    }
    .da-tooltip button:hover { background: #b8860b; color: #000000; }

    .da-note-editor {
      position: absolute;
      background: #ffffff;
      border: 2px solid #000000;
      padding: 8px;
      width: 220px;
      z-index: 2147483647;
      pointer-events: auto;
    }
    .da-note-editor textarea {
      width: 100%;
      min-height: 70px;
      resize: vertical;
      border: 1px solid #000000;
      padding: 6px;
      font-size: 13px;
      font-family: inherit;
      color: #000000;
      background: #ffffff;
    }
    .da-note-actions { display: flex; justify-content: space-between; margin-top: 6px; }
    .da-note-actions button {
      border: 1.5px solid #000000;
      background: #ffffff;
      color: #000000;
      padding: 4px 10px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
    }
    .da-btn-save { background: #b8860b !important; color: #000000 !important; }
    .da-btn-delete:hover { background: #000000; color: #ffffff; }

    .da-mascot {
      position: fixed;
      bottom: 16px;
      right: 16px;
      width: 72px;
      height: 72px;
      cursor: pointer;
      z-index: 2147483647;
      pointer-events: auto;
    }
    .da-mascot svg { width: 100%; height: 100%; overflow: visible; display: block; }
    .da-mascot:hover { animation: da-wiggle .32s ease-in-out 2; }
    .da-mascot[data-emotion="happy"], .da-mascot[data-emotion="excited"] { animation: da-bounce .45s ease-in-out 2; }
    .da-mascot[data-emotion="excited"] svg { animation: da-spin .55s ease-in-out 2; }
    .da-mascot[data-emotion="thinking"] svg { animation: da-tilt .8s ease-in-out infinite alternate; }
    .da-mascot[data-emotion="sad"] svg { filter: grayscale(.35); transform: rotate(-8deg); }
    .da-mascot[data-emotion="sleepy"] { opacity: .72; transform: translateY(5px); }
    .da-mascot[data-emotion="alert"] svg { animation: da-alert .28s ease-in-out 3; }
    .da-mascot[data-emotion="depart"] { animation: da-jump-away .8s ease-in forwards; }
    .da-eye { transform-origin: center; animation: da-blink 5s infinite; }
    .da-mascot[data-emotion="sleepy"] .da-eye { transform: scaleY(.15); }
    .da-mouth { stroke: #000; stroke-width: 2; fill: none; }
    .da-mascot[data-emotion="happy"] .da-mouth { d: path('M 68 42 Q 72 47 76 42'); }
    .da-mascot[data-emotion="sad"] .da-mouth { d: path('M 68 47 Q 72 42 76 47'); }
    .da-foot { transform-origin: 44px 78px; animation: da-flap 0.6s ease-in-out infinite alternate; }
    .da-foot-right { transform-origin: 52px 78px; animation-delay: 0.3s; }
    @keyframes da-flap {
      0%   { transform: rotate(-14deg); }
      100% { transform: rotate(14deg); }
    }
    @keyframes da-bounce { 50% { transform: translateY(-9px) scale(1.06); } }
    @keyframes da-tilt { to { transform: rotate(7deg); } }
    @keyframes da-wiggle { 50% { transform: rotate(10deg) scale(1.08); } }
    @keyframes da-spin { 50% { transform: rotate(-10deg); } }
    @keyframes da-alert { 50% { transform: translateY(-6px) scale(1.12); } }
    @keyframes da-jump-away { 35% { transform: translateY(-55px) rotate(-18deg) scale(1.08); } 100% { transform: translateX(150px) translateY(-130px) rotate(35deg) scale(.15); opacity: 0; } }
    @keyframes da-blink { 0%, 93%, 100% { transform: scaleY(1); } 96% { transform: scaleY(.1); } }
    .da-speech {
      position: absolute;
      bottom: 82px;
      right: 0;
      max-width: 190px;
      background: #090909;
      color: #ffffff;
      border: 2px solid #000000;
      color: #000000;
      padding: 8px 10px;
      font-size: 12px;
      line-height: 1.4;
    }

    .da-side-panel {
      position: fixed;
      top: 0;
      right: 0;
      width: min(360px, 92vw);
      height: 100vh;
      background: #050505;
      color: #ffffff;
      display: flex;
      flex-direction: column;
      z-index: 2147483647;
      pointer-events: auto;
      border-left: 3px solid #b8860b;
      box-shadow: -8px 0 28px #0008;
    }
    .da-tabs { display: flex; border-bottom: 1px solid #555; }
    .da-tabs button { flex: 1; padding: 10px; border: 0; border-right: 1px solid #555; background: #171717; color: #fff; font-weight: 700; cursor: pointer; }
    .da-tabs button.active { background: #b8860b; color: #000; }
    .da-panel { display: none; flex: 1; min-height: 0; flex-direction: column; }
    .da-panel.active { display: flex; }
    .da-chat-header {
      background: #050505;
      color: #e2b93b;
      border-bottom: 1px solid #b8860b;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 1px;
      padding: 8px 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .da-panel-logo { width: 30px; height: 30px; display: inline-block; margin-right: 5px; }
    .da-panel-logo svg { width: 100%; height: 100%; display: block; }
    .da-collection { overflow-y: auto; padding: 10px; color: #fff; }
    .da-collection-item { width: 100%; display: block; text-align: left; padding: 9px; margin: 0 0 8px; border: 1px solid #555; background: #171717; color: #fff; cursor: pointer; font-size: 12px; }
    .da-collection-item:hover { border-color: #b8860b; }
    .da-collection-item small { display: block; margin-top: 4px; color: #ccc; }
    .da-collection-actions { display: flex; gap: 6px; padding: 10px; border-top: 1px solid #555; }
    .da-collection-actions button, .da-clear-panel { border: 2px solid #b8860b; background: #171717; color: #e2b93b; padding: 7px 8px; font-size: 11px; font-weight: 700; cursor: pointer; }
    .da-collection-actions button:first-child { background: #b8860b; color: #000; }
    .da-clear-panel { margin-left: auto; padding: 4px 7px !important; border-width: 1px !important; }
    .da-chat-header button {
      background: transparent;
      border: none;
      color: #e2b93b;
      cursor: pointer;
      font-size: 14px;
      line-height: 1;
    }
    .da-chat-header .da-clear-panel { background: #050505; border: 1px solid #b8860b; color: #e2b93b; cursor: pointer; }
    .da-chat-header .da-clear-panel:hover { background: #e2b93b; color: #000; }
    .da-chat-log {
      flex: 1;
      overflow-y: auto;
      padding: 8px;
      font-size: 12px;
      line-height: 1.4;
    }
    .da-chat-msg { margin-bottom: 8px; }
    .da-chat-msg.user { text-align: right; }
    .da-chat-msg span {
      display: inline-block;
      max-width: 85%;
      padding: 6px 8px;
      border: 1.5px solid #555;
    }
    .da-chat-msg.user span { background: #b8860b; color: #000; border-color: #b8860b; }
    .da-chat-msg.duck span { background: #171717; color: #ffffff; border-color: #555; }
    .da-chat-input-row {
      display: flex;
      border-top: 1px solid #555;
    }
    .da-chat-input-row input {
      flex: 1;
      border: none;
      padding: 8px;
      font-size: 12px;
      font-family: inherit;
      color: #fff;
      background: #171717;
    }
    .da-chat-input-row input:focus { outline: none; }
    .da-chat-input-row button {
      border: none;
      border-left: 1px solid #b8860b;
      background: #b8860b;
      color: #000000;
      font-weight: 700;
      padding: 0 14px;
      cursor: pointer;
    }
  `;

  const DUCK_SVG = `
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="46" cy="58" rx="30" ry="22" fill="#FFD500"/>
      <ellipse cx="28" cy="52" rx="11" ry="7" fill="#FFC300"/>
      <circle cx="72" cy="34" r="16" fill="#FFD500"/>
      <circle class="da-eye" cx="78" cy="30" r="2.4" fill="#000000"/>
      <path class="da-mouth" d="M68 44 L76 44"/>
      <path d="M85 35 L98 32 L85 41 Z" fill="#FF8C00"/>
      <path class="da-foot da-foot-left" d="M36 78 L30 92 L42 92 L38 80 Z" fill="#FF8C00"/>
      <path class="da-foot da-foot-right" d="M52 78 L48 92 L60 92 L54 80 Z" fill="#FF8C00"/>
    </svg>
  `;

  function ensureShadowRoot() {
    if (shadowRoot) return shadowRoot;
    shadowHost = document.createElement('div');
    shadowHost.id = 'duck-annotator-shadow-host';
    shadowHost.style.setProperty('pointer-events', 'none', 'important');
    shadowHost.style.setProperty('position', 'static', 'important');
    document.documentElement.appendChild(shadowHost);
    shadowRoot = shadowHost.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = SHADOW_STYLES;
    shadowRoot.appendChild(style);
    return shadowRoot;
  }

  /** True if the event's real target (composed path) is inside an element with `className`. */
  function pathHasClass(e, className) {
    return e.composedPath().some((el) => el.classList && el.classList.contains(className));
  }

  // ---------------------------------------------------------------------
  // XPath anchoring — how a highlight survives a page refresh
  // ---------------------------------------------------------------------

  function getXPath(node) {
    if (!node || node.nodeType === Node.DOCUMENT_NODE) return '';
    if (node === document.documentElement) return '/html';
    if (node === document.body) return '/html/body';

    const parent = node.parentNode;
    if (!parent) return '';

    if (node.nodeType === Node.TEXT_NODE) {
      const textSiblings = Array.prototype.filter.call(parent.childNodes, (n) => n.nodeType === Node.TEXT_NODE);
      const index = textSiblings.indexOf(node) + 1;
      return getXPath(parent) + '/text()[' + index + ']';
    }

    const sameTagSiblings = Array.prototype.filter.call(
      parent.childNodes,
      (n) => n.nodeType === Node.ELEMENT_NODE && n.tagName === node.tagName
    );
    const index = sameTagSiblings.indexOf(node) + 1;
    return getXPath(parent) + '/' + node.tagName.toLowerCase() + '[' + index + ']';
  }

  function getNodeByXPath(xpath) {
    try {
      return document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    } catch (e) {
      return null;
    }
  }

  function serializeRange(range) {
    const offsets = rangeOffsets(range);
    return {
      startXPath: getXPath(range.startContainer),
      startOffset: range.startOffset,
      endXPath: getXPath(range.endContainer),
      endOffset: range.endOffset,
      text: range.toString(), ...offsets,
      quotePrefix: Number.isInteger(offsets.startTextOffset) ? pageText().slice(Math.max(0, offsets.startTextOffset - 80), offsets.startTextOffset) : '',
      quoteSuffix: Number.isInteger(offsets.endTextOffset) ? pageText().slice(offsets.endTextOffset, offsets.endTextOffset + 80) : ''
    };
  }

  function pageText() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let text = '';
    while (walker.nextNode()) text += walker.currentNode.data;
    return text;
  }

  function rangeOffsets(range) {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let pos = 0, start = null, end = null;
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node === range.startContainer) start = pos + range.startOffset;
      if (node === range.endContainer) { end = pos + range.endOffset; break; }
      pos += node.length;
    }
    return Number.isInteger(start) && Number.isInteger(end) ? { startTextOffset: start, endTextOffset: end } : {};
  }

  function rangeFromOffsets(data) {
    if (!Number.isInteger(data.startTextOffset) || !Number.isInteger(data.endTextOffset)) return null;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let pos = 0, startNode, endNode, startOffset, endOffset;
    while (walker.nextNode()) {
      const node = walker.currentNode, next = pos + node.length;
      if (!startNode && data.startTextOffset >= pos && data.startTextOffset <= next) { startNode = node; startOffset = data.startTextOffset - pos; }
      if (data.endTextOffset >= pos && data.endTextOffset <= next) { endNode = node; endOffset = data.endTextOffset - pos; break; }
      pos = next;
    }
    if (!startNode || !endNode) return null;
    const range = document.createRange();
    range.setStart(startNode, startOffset); range.setEnd(endNode, endOffset);
    return range.toString() === data.text ? range : null;
  }

  function deserializeRange(data) {
    const page = pageText();
    let index = -1, cursor = 0, closest = -1, distance = Infinity;
    while ((cursor = page.indexOf(data.text, cursor)) !== -1) {
      const prefixOK = !data.quotePrefix || page.slice(Math.max(0, cursor - data.quotePrefix.length), cursor) === data.quotePrefix;
      const end = cursor + data.text.length;
      const suffixOK = !data.quoteSuffix || page.slice(end, end + data.quoteSuffix.length) === data.quoteSuffix;
      if (prefixOK && suffixOK) { index = cursor; break; }
      const delta = Math.abs(cursor - (data.startTextOffset || 0));
      if (delta < distance) { closest = cursor; distance = delta; }
      cursor += Math.max(1, data.text.length);
    }
    if (index < 0) index = closest;
    if (index >= 0) {
      const quoteRange = rangeFromOffsets({ ...data, startTextOffset: index, endTextOffset: index + data.text.length });
      if (quoteRange) return quoteRange;
    }
    const offsetRange = rangeFromOffsets(data);
    if (offsetRange) return offsetRange;
    const startNode = getNodeByXPath(data.startXPath);
    const endNode = getNodeByXPath(data.endXPath);
    if (!startNode || !endNode) return null;
    try {
      const range = document.createRange();
      range.setStart(startNode, data.startOffset);
      range.setEnd(endNode, data.endOffset);
      // Guard: if the page shifted slightly, offsets can resolve to the *wrong*
      // text without throwing. Reject silently-wrong anchors instead of
      // highlighting the wrong sentence.
      if (range.toString() !== data.text) return null;
      return range;
    } catch (e) {
      return null; // page structure changed too much to re-anchor — skip (no fuzzy fallback, by design)
    }
  }

  // ---------------------------------------------------------------------
  // Wrapping a Range in <span> highlights (handles multi-node selections)
  // ---------------------------------------------------------------------

  function wrapRangeInSpans(range, annotationId) {
    const root = range.commonAncestorContainer.nodeType === Node.TEXT_NODE
      ? range.commonAncestorContainer.parentNode
      : range.commonAncestorContainer;

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) {
      if (range.intersectsNode(walker.currentNode)) textNodes.push(walker.currentNode);
    }

    const createdSpans = [];
    textNodes.forEach((textNode) => {
      const start = (textNode === range.startContainer) ? range.startOffset : 0;
      const end = (textNode === range.endContainer) ? range.endOffset : textNode.length;
      if (start >= end) return;

      let node = textNode;
      if (end < node.length) node.splitText(end);
      if (start > 0) node = node.splitText(start);

      const span = document.createElement('span');
      span.className = 'duck-annotator-highlight';
      span.dataset.annotationId = annotationId;
      node.parentNode.insertBefore(span, node);
      span.appendChild(node);
      createdSpans.push(span);
    });

    return createdSpans;
  }

  function insertNoteIcon(spans, annotation) {
    if (!spans.length) return;
    const icon = document.createElement('span');
    icon.className = 'duck-annotator-note-icon';
    icon.dataset.annotationId = annotation.id;
    icon.title = annotation.note ? 'View note' : 'Add note';
    if (annotation.note) icon.classList.add('has-note');
    icon.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleNoteEditor(annotation.id, icon);
    });
    spans[spans.length - 1].after(icon);
  }

  // ---------------------------------------------------------------------
  // Persistence
  // ---------------------------------------------------------------------

  function persist() {
    chrome.storage.local.set({ [PAGE_KEY]: [...annotations, ...unresolvedAnnotations] });
  }

  function loadAndRender(callback) {
    chrome.storage.local.get([PAGE_KEY], (result) => {
      const saved = result[PAGE_KEY] || [];
      const rendered = [];
      saved.forEach((annotation) => {
        const range = deserializeRange(annotation);
        if (!range) return;
        const anchored = { ...annotation, ...serializeRange(range) };
        const spans = wrapRangeInSpans(range, anchored.id);
        if (!spans.length) return;
        insertNoteIcon(spans, anchored);
        rendered.push(anchored);
      });
      annotations = rendered;
      unresolvedAnnotations = saved.filter((annotation) => !rendered.some((item) => item.id === annotation.id));
      if (rendered.length) persist();
      if (callback) callback();
    });
  }

  // ---------------------------------------------------------------------
  // Creating / deleting highlights
  // ---------------------------------------------------------------------

  function createHighlight(range) {
    const existing = [...document.querySelectorAll('.duck-annotator-highlight')]
      .filter((span) => { try { return range.intersectsNode(span); } catch (_) { return false; } })
      .map((span) => span.dataset.annotationId);
    if (existing.length) {
      [...new Set(existing)].forEach(deleteAnnotation);
      setDuckEmotion('sad', 700);
      return;
    }
    const id = 'da_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
    const serialized = serializeRange(range);
    const spans = wrapRangeInSpans(range, id);
    if (!spans.length) return;
    const annotation = { id, ...serialized, note: '', createdAt: Date.now() };
    annotations.push(annotation);
    insertNoteIcon(spans, annotation);
    persist();
    setDuckEmotion('happy', 900);
  }

  function deleteAnnotation(id) {
    document.querySelectorAll('.duck-annotator-highlight[data-annotation-id="' + id + '"]').forEach((span) => {
      const parent = span.parentNode;
      while (span.firstChild) parent.insertBefore(span.firstChild, span);
      parent.removeChild(span);
      parent.normalize();
    });
    const icon = document.querySelector('.duck-annotator-note-icon[data-annotation-id="' + id + '"]');
    if (icon) icon.remove();
    annotations = annotations.filter((a) => a.id !== id);
    unresolvedAnnotations = unresolvedAnnotations.filter((a) => a.id !== id);
    persist();
  }

  function clearPageHighlights() {
    [...annotations].forEach((annotation) => deleteAnnotation(annotation.id));
    unresolvedAnnotations = [];
    persist();
    setDuckEmotion('sad', 700);
  }

  // ---------------------------------------------------------------------
  // Selection tooltip
  // ---------------------------------------------------------------------

  function removeTooltip() {
    if (tooltipEl) { tooltipEl.remove(); tooltipEl = null; }
  }

  function showTooltip(range) {
    removeTooltip();
    const rect = range.getBoundingClientRect();
    const root = ensureShadowRoot();

    tooltipEl = document.createElement('div');
    tooltipEl.className = 'da-tooltip';
    tooltipEl.innerHTML = '<button type="button" class="da-highlight-selection">&#9998; Highlight</button><button type="button" class="da-ask-selection">Ask</button>';
    root.appendChild(tooltipEl);

    const top = rect.top + window.scrollY - tooltipEl.offsetHeight - 8;
    const left = rect.left + window.scrollX;
    tooltipEl.style.top = Math.max(top, window.scrollY + 4) + 'px';
    tooltipEl.style.left = left + 'px';

    tooltipEl.querySelector('.da-highlight-selection').addEventListener('mousedown', (evt) => {
      evt.preventDefault(); // don't collapse the selection before we read it
      createHighlight(range.cloneRange());
      removeTooltip();
      window.getSelection().removeAllRanges();
    });
    tooltipEl.querySelector('.da-ask-selection').addEventListener('mousedown', (evt) => {
      evt.preventDefault();
      askAboutText(range.toString().trim());
      removeTooltip();
      window.getSelection().removeAllRanges();
    });
  }

  document.addEventListener('mouseup', (e) => {
    if (pathHasClass(e, 'da-tooltip') || pathHasClass(e, 'da-note-editor') || pathHasClass(e, 'da-mascot') || pathHasClass(e, 'da-side-panel')) return;
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.toString().trim()) {
      removeTooltip();
      return;
    }
    showTooltip(selection.getRangeAt(0));
  });

  // ---------------------------------------------------------------------
  // Note editor
  // ---------------------------------------------------------------------

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  function closeNoteEditor() {
    if (noteEditorEl) { noteEditorEl.remove(); noteEditorEl = null; }
    activeNoteId = null;
  }

  function toggleNoteEditor(annotationId, anchorEl) {
    const reopeningSame = activeNoteId === annotationId;
    closeNoteEditor();
    if (reopeningSame) return;

    const annotation = annotations.find((a) => a.id === annotationId);
    if (!annotation) return;
    activeNoteId = annotationId;

    const root = ensureShadowRoot();
    noteEditorEl = document.createElement('div');
    noteEditorEl.className = 'da-note-editor';
    noteEditorEl.innerHTML =
      '<textarea placeholder="Add a note...">' + escapeHtml(annotation.note) + '</textarea>' +
      '<div class="da-note-actions">' +
      '<button type="button" class="da-btn-delete">Delete</button>' +
      '<button type="button" class="da-btn-save">Save</button>' +
      '</div>';
    root.appendChild(noteEditorEl);

    const rect = anchorEl.getBoundingClientRect();
    noteEditorEl.style.top = (rect.bottom + window.scrollY + 6) + 'px';
    noteEditorEl.style.left = (rect.left + window.scrollX) + 'px';

    const textarea = noteEditorEl.querySelector('textarea');
    textarea.focus();

    noteEditorEl.querySelector('.da-btn-save').addEventListener('click', () => {
      annotation.note = textarea.value.trim();
      persist();
      anchorEl.classList.toggle('has-note', !!annotation.note);
      anchorEl.title = annotation.note ? 'View note' : 'Add note';
      closeNoteEditor();
    });
    noteEditorEl.querySelector('.da-btn-delete').addEventListener('click', () => {
      deleteAnnotation(annotationId);
      closeNoteEditor();
    });
  }

  document.addEventListener('mousedown', (e) => {
    if (tooltipEl && !pathHasClass(e, 'da-tooltip')) removeTooltip();
    if (noteEditorEl && !pathHasClass(e, 'da-note-editor') && !e.target.closest('.duck-annotator-note-icon')) {
      closeNoteEditor();
    }
  });

  // ---------------------------------------------------------------------
  // Mascot
  // ---------------------------------------------------------------------

  const STATIC_TIPS = [
    'Select any text and hit Highlight to save it.',
    'Click the small square icon next to a highlight to add a note.',
    'Everything stays on your device — nothing is ever uploaded.'
  ];

  let mascotEl = null;
  let sidePanelEl = null;
  let emotionTimer = null;
  let greetingTimer = null;

  function recognizedSite() {
    const host = location.hostname.replace(/^www\./, '').split('.').slice(-2).join('.');
    return { 'youtube.com': 'YouTube', 'facebook.com': 'Facebook', 'instagram.com': 'Instagram', 'x.com': 'X', 'twitter.com': 'X', 'tiktok.com': 'TikTok', 'linkedin.com': 'LinkedIn', 'reddit.com': 'Reddit' }[host] || null;
  }

  function greetRecognizedSite() {
    if (!recognizedSite() || !mascotEl) return;
    setDuckEmotion('depart');
    clearTimeout(greetingTimer);
    greetingTimer = setTimeout(() => { if (mascotEl) mascotEl.style.display = 'none'; }, 800);
  }

  function pickTip() {
    const count = annotations.length;
    const dynamic = count === 0
      ? 'No highlights yet on this page — select some text to start!'
      : `You've saved ${count} highlight${count === 1 ? '' : 's'} on this page.`;
    const pool = [dynamic, ...STATIC_TIPS];
    return pool[Math.floor(Math.random() * pool.length)];
  }

  function initMascot(enabled) {
    if (!enabled || mascotEl) return;
    const root = ensureShadowRoot();
    mascotEl = document.createElement('div');
    mascotEl.className = 'da-mascot';
    mascotEl.title = 'Ask the duck';
    mascotEl.innerHTML = DUCK_SVG;
    root.appendChild(mascotEl);
    mascotEl.addEventListener('click', () => { setDuckEmotion('excited', 850); sidePanelEl ? closeSidePanel() : openSidePanel(); });
    greetRecognizedSite();
  }

  function setDuckEmotion(emotion, duration) {
    if (!mascotEl) return;
    clearTimeout(emotionTimer);
    mascotEl.dataset.emotion = emotion;
    const mouth = mascotEl.querySelector('.da-mouth');
    if (mouth) mouth.setAttribute('d', emotion === 'happy' ? 'M68 42 Q72 47 76 42' : emotion === 'sad' ? 'M68 47 Q72 42 76 47' : 'M68 44 L76 44');
    if (duration) emotionTimer = setTimeout(() => setDuckEmotion('idle'), duration);
  }

  function appendChatMsg(role, text) {
    const row = document.createElement('div');
    row.className = 'da-chat-msg ' + role;
    const bubble = document.createElement('span');
    bubble.textContent = text;
    row.appendChild(bubble);
    const log = sidePanelEl.querySelector('.da-chat-log');
    log.appendChild(row);
    log.scrollTop = log.scrollHeight;
  }

  function askAboutText(text) {
    if (!text) return;
    if (!sidePanelEl) openSidePanel();
    sidePanelEl.querySelector('.da-tabs button[data-panel="chat"]').click();
    appendChatMsg('user', 'Explain this selection:\n“' + text + '”');
    appendChatMsg('duck', '...');
    const bubble = sidePanelEl.querySelector('.da-chat-log').lastChild;
    setDuckEmotion('thinking');
    chrome.runtime.sendMessage({ action: 'callGemini', prompt: 'Explain this selected text clearly, including key concepts and any important context:\n\n' + text }, (response) => {
      bubble.querySelector('span').textContent = (response && (response.text || response.error)) || 'Something went wrong.';
      setDuckEmotion(response && response.text ? 'happy' : 'sad', 900);
    });
  }

  function renderCollection() {
    const list = sidePanelEl.querySelector('.da-collection');
    list.textContent = '';
    if (!annotations.length) list.textContent = 'No highlights on this page yet.';
    annotations.forEach((annotation) => {
      const item = document.createElement('button');
      item.type = 'button'; item.className = 'da-collection-item';
      item.textContent = annotation.text;
      if (annotation.note) { const note = document.createElement('small'); note.textContent = annotation.note; item.appendChild(note); }
      item.addEventListener('click', () => scrollToAnnotation(annotation.id));
      list.appendChild(item);
    });
  }

  function collectionText() {
    return annotations.map((a, i) => `${i + 1}. ${a.text}${a.note ? `\nNote: ${a.note}` : ''}`).join('\n\n');
  }

  function scrollToAnnotation(id) {
    const span = document.querySelector('.duck-annotator-highlight[data-annotation-id="' + id + '"]');
    if (!span) return false;
    span.scrollIntoView({ behavior: 'smooth', block: 'center' });
    span.classList.add('duck-annotator-flash');
    setTimeout(() => span.classList.remove('duck-annotator-flash'), 1200);
    return true;
  }

  function summarizeHighlights() {
    if (!annotations.length) return appendChatMsg('duck', 'Add highlights first, then I can summarize them.');
    const tabs = sidePanelEl.querySelectorAll('.da-tabs button');
    tabs[0].click();
    appendChatMsg('duck', 'Summarizing your highlights…');
    const bubble = sidePanelEl.querySelector('.da-chat-log').lastChild;
    setDuckEmotion('thinking');
    chrome.runtime.sendMessage({ action: 'callGemini', prompt: 'Summarize these saved highlights clearly and concisely:\n\n' + collectionText() }, (response) => {
      bubble.querySelector('span').textContent = (response && (response.text || response.error)) || 'Something went wrong.';
      setDuckEmotion(response && response.text ? 'happy' : 'sad', 900);
    });
  }

  function exportToObsidian() {
    const content = `# Duck Annotator Highlights\n\nSource: ${location.href}\n\n${collectionText() || 'No highlights.'}`;
    chrome.runtime.sendMessage({ action: 'openObsidian', content, title: document.title || 'Duck Annotator Highlights' });
  }

  function closeSidePanel() {
    if (sidePanelEl) { sidePanelEl.remove(); sidePanelEl = null; }
  }

  function openSidePanel() {
    const root = ensureShadowRoot();
    sidePanelEl = document.createElement('aside');
    sidePanelEl.className = 'da-side-panel';
    sidePanelEl.innerHTML = '<div class="da-chat-header"><span class="da-panel-logo" aria-hidden="true">' + DUCK_SVG + '</span><span>DUCK ANNOTATOR</span><button type="button" class="da-clear-panel">Clear Page</button><button type="button" class="da-chat-close">&times;</button></div><div class="da-tabs"><button type="button" class="active" data-panel="chat">Chat</button><button type="button" data-panel="collection">Highlights & Notes</button></div><section class="da-panel da-chat-panel active"><div class="da-chat-log"></div><div class="da-chat-input-row"><input type="text" placeholder="Ask about this page..." /><button type="button">Send</button></div></section><section class="da-panel da-collection-panel"><div class="da-collection"></div><div class="da-collection-actions"><button type="button" class="da-summarize">Summarize Highlights</button><button type="button" class="da-obsidian">Export to Obsidian</button></div></section>';
    root.appendChild(sidePanelEl);

    appendChatMsg('duck', pickTip());

    sidePanelEl.querySelector('.da-chat-close').addEventListener('click', closeSidePanel);
    sidePanelEl.querySelector('.da-clear-panel').addEventListener('click', clearPageHighlights);
    sidePanelEl.querySelectorAll('.da-tabs button').forEach((tab) => tab.addEventListener('click', () => {
      sidePanelEl.querySelectorAll('.da-tabs button').forEach((button) => button.classList.toggle('active', button === tab));
      sidePanelEl.querySelector('.da-chat-panel').classList.toggle('active', tab.dataset.panel === 'chat');
      sidePanelEl.querySelector('.da-collection-panel').classList.toggle('active', tab.dataset.panel === 'collection');
      if (tab.dataset.panel === 'collection') renderCollection();
    }));
    sidePanelEl.querySelector('.da-summarize').addEventListener('click', summarizeHighlights);
    sidePanelEl.querySelector('.da-obsidian').addEventListener('click', exportToObsidian);

    const input = sidePanelEl.querySelector('input');
    const sendBtn = sidePanelEl.querySelector('.da-chat-input-row button');
    const send = () => {
      const text = input.value.trim();
      if (!text) return;
      appendChatMsg('user', text);
      input.value = '';
      appendChatMsg('duck', '...');
      const thinkingBubble = sidePanelEl.querySelector('.da-chat-log').lastChild;
      setDuckEmotion('thinking');
      chrome.runtime.sendMessage({ action: 'callGemini', prompt: text }, (response) => {
        thinkingBubble.querySelector('span').textContent =
          (response && (response.text || response.error)) || 'Something went wrong.';
        setDuckEmotion(response && response.text ? 'happy' : 'sad', 900);
      });
    };
    sendBtn.addEventListener('click', send);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });
    input.focus();
  }

  function setMascotEnabled(enabled) {
    if (enabled) {
      initMascot(true);
    } else if (mascotEl) {
      closeSidePanel();
      mascotEl.remove();
      mascotEl = null;
    }
  }

  // ---------------------------------------------------------------------
  // Messages from popup / background
  // ---------------------------------------------------------------------

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
      case 'getAnnotations':
        sendResponse({ annotations });
        break;
      case 'scrollToAnnotation': {
        sendResponse({ ok: scrollToAnnotation(message.id) });
        break;
      }
      case 'clearPageHighlights':
        clearPageHighlights(); sendResponse({ ok: true }); break;
      case 'deleteAnnotation':
        deleteAnnotation(message.id);
        sendResponse({ ok: true });
        break;
      case 'setMascotEnabled':
        setMascotEnabled(message.enabled);
        sendResponse({ ok: true });
        break;
      case 'highlightSelectionFromContextMenu': {
        const selection = window.getSelection();
        if (selection && !selection.isCollapsed) {
          createHighlight(selection.getRangeAt(0).cloneRange());
          selection.removeAllRanges();
        }
        break;
      }
    }
    return true;
  });

  // ---------------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------------

  function init() {
    chrome.storage.local.get(['duckAnnotatorSettings'], (res) => {
      const settings = res.duckAnnotatorSettings || { mascotEnabled: true };
      loadAndRender(() => initMascot(settings.mascotEnabled !== false));
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
