'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const listEl = document.getElementById('annotation-list');
  const emptyEl = document.getElementById('empty-state');
  const mascotToggle = document.getElementById('mascot-toggle');
  const clearBtn = document.getElementById('clear-all-btn');
  const optionsBtn = document.getElementById('options-btn');

  let currentTabId = null;

  chrome.storage.local.get(['duckAnnotatorSettings'], (res) => {
    mascotToggle.checked = (res.duckAnnotatorSettings || {}).mascotEnabled !== false;
  });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.id) return;
    currentTabId = tab.id;
    chrome.tabs.sendMessage(tab.id, { action: 'getAnnotations' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        emptyEl.textContent = 'Reload this page to use Duck Annotator here.';
        emptyEl.hidden = false;
        return;
      }
      renderList(response.annotations || []);
    });
  });

  function renderList(items) {
    listEl.innerHTML = '';
    if (!items.length) {
      emptyEl.hidden = false;
      return;
    }
    emptyEl.hidden = true;

    items.forEach((a) => {
      const li = document.createElement('li');
      li.className = 'annotation-item';

      const textSpan = document.createElement('span');
      textSpan.className = 'annotation-text';
      textSpan.textContent = a.text.length > 80 ? a.text.slice(0, 80) + '…' : a.text;
      if (a.note) {
        const noteSpan = document.createElement('span');
        noteSpan.className = 'annotation-note';
        noteSpan.textContent = '📝 ' + a.note;
        textSpan.appendChild(noteSpan);
      }
      li.appendChild(textSpan);

      const delBtn = document.createElement('button');
      delBtn.className = 'annotation-delete';
      delBtn.textContent = '✕';
      delBtn.title = 'Delete';
      delBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.tabs.sendMessage(currentTabId, { action: 'deleteAnnotation', id: a.id }, () => {
          li.remove();
          if (!listEl.children.length) emptyEl.hidden = false;
        });
      });
      li.appendChild(delBtn);

      li.addEventListener('click', () => {
        chrome.tabs.sendMessage(currentTabId, { action: 'scrollToAnnotation', id: a.id });
        window.close();
      });

      listEl.appendChild(li);
    });
  }

  mascotToggle.addEventListener('change', () => {
    const enabled = mascotToggle.checked;
    chrome.storage.local.get(['duckAnnotatorSettings'], (res) => {
      const settings = res.duckAnnotatorSettings || {};
      settings.mascotEnabled = enabled;
      chrome.storage.local.set({ duckAnnotatorSettings: settings });
    });
    if (currentTabId) chrome.tabs.sendMessage(currentTabId, { action: 'setMascotEnabled', enabled });
  });

  clearBtn.addEventListener('click', () => {
    if (!currentTabId) return;
    if (!confirm('Delete all highlights on this page?')) return;
    chrome.tabs.sendMessage(currentTabId, { action: 'getAnnotations' }, (response) => {
      const items = (response && response.annotations) || [];
      items.forEach((a) => chrome.tabs.sendMessage(currentTabId, { action: 'deleteAnnotation', id: a.id }));
      listEl.innerHTML = '';
      emptyEl.hidden = false;
    });
  });

  optionsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
});
