'use strict';

/**
 * Background service worker.
 * Single job: bootstrap default settings on install, and relay a
 * right-click context-menu action to the content script. Everything
 * else (state, rendering, persistence) lives in content.js — the
 * worker is intentionally thin (YAGNI: no message bus, no queue).
 */

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['duckAnnotatorSettings'], (res) => {
    if (!res.duckAnnotatorSettings) {
      chrome.storage.local.set({ duckAnnotatorSettings: { mascotEnabled: true } });
    }
  });

  chrome.contextMenus.create({
    id: 'duck-annotator-highlight',
    title: 'Highlight with Duck Annotator',
    contexts: ['selection']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'duck-annotator-highlight' && tab && tab.id) {
    chrome.tabs.sendMessage(tab.id, { action: 'highlightSelectionFromContextMenu' });
  }
});

/**
 * Duck chat -> Gemini API relay. Lives here (not in content.js) so the API
 * key never has to be passed into the page context. Reads the key/model
 * straight from storage — single source of truth, no message payload needed.
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'openObsidian') {
    const url = 'obsidian://new?name=' + encodeURIComponent(message.title) + '&content=' + encodeURIComponent(message.content);
    chrome.tabs.create({ url }, () => sendResponse({ ok: !chrome.runtime.lastError }));
    return true;
  }
  if (message.action !== 'callGemini') return false;
  chrome.storage.local.get(['duckAnnotatorSettings'], async (res) => {
    const settings = res.duckAnnotatorSettings || {};
    const apiKey = settings.geminiApiKey;
    const model = settings.geminiModel || 'gemini-flash-latest';
    if (!apiKey) {
      sendResponse({ error: 'No Gemini API key set yet. Add one in the extension\u2019s settings.' });
      return;
    }
    try {
      const res2 = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
          body: JSON.stringify({ contents: [{ parts: [{ text: message.prompt }] }] })
        }
      );
      const data = await res2.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      sendResponse({ text: text || (data?.error?.message ? 'Gemini error: ' + data.error.message : 'No response.') });
    } catch (e) {
      sendResponse({ error: 'Could not reach Gemini: ' + e.message });
    }
  });
  return true; // keep the message channel open for the async sendResponse above
});
