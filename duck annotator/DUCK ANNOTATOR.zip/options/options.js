'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const mascotToggle = document.getElementById('mascot-toggle');
  const clearAllBtn = document.getElementById('clear-all-data-btn');
  const statusEl = document.getElementById('status');
  const geminiKeyInput = document.getElementById('gemini-key');
  const geminiModelInput = document.getElementById('gemini-model');
  const saveGeminiBtn = document.getElementById('save-gemini-btn');

  chrome.storage.local.get(['duckAnnotatorSettings'], (res) => {
    const settings = res.duckAnnotatorSettings || {};
    mascotToggle.checked = settings.mascotEnabled !== false;
    geminiKeyInput.value = settings.geminiApiKey || '';
    geminiModelInput.value = settings.geminiModel || 'gemini-flash-latest';
  });

  saveGeminiBtn.addEventListener('click', () => {
    chrome.storage.local.get(['duckAnnotatorSettings'], (res) => {
      const settings = res.duckAnnotatorSettings || {};
      settings.geminiApiKey = geminiKeyInput.value.trim();
      settings.geminiModel = geminiModelInput.value.trim() || 'gemini-flash-latest';
      chrome.storage.local.set({ duckAnnotatorSettings: settings }, () => showStatus('Gemini settings saved.'));
    });
  });

  mascotToggle.addEventListener('change', () => {
    chrome.storage.local.get(['duckAnnotatorSettings'], (res) => {
      const settings = res.duckAnnotatorSettings || {};
      settings.mascotEnabled = mascotToggle.checked;
      chrome.storage.local.set({ duckAnnotatorSettings: settings }, () => showStatus('Saved.'));
    });
  });

  clearAllBtn.addEventListener('click', () => {
    if (!confirm('This deletes every highlight and note on every page. Continue?')) return;
    chrome.storage.local.clear(() => {
      chrome.storage.local.set({ duckAnnotatorSettings: { mascotEnabled: mascotToggle.checked } });
      showStatus('All Duck Annotator data has been cleared.');
    });
  });

  function showStatus(msg) {
    statusEl.textContent = msg;
    statusEl.hidden = false;
    setTimeout(() => { statusEl.hidden = true; }, 2500);
  }
});
